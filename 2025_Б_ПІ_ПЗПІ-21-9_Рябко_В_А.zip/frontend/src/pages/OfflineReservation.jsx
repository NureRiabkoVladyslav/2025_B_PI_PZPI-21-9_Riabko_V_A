import { useState } from "react";
import { Navigate } from "react-router-dom";
import FormInput from "../components/FormInput";
import api from "../api/api";
import { useAuth } from "../context/AuthContext";

function OfflineReservation() {
  const { user, access } = useAuth();
  const [userIdentifier, setUserIdentifier] = useState("");
  const [bookIdentifier, setBookIdentifier] = useState("");
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'userIdentifier') setUserIdentifier(value);
    if (name === 'bookIdentifier') setBookIdentifier(value);
    setErrors((prev) => ({ ...prev, [name]: "" }));
    setApiError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!userIdentifier || !bookIdentifier) {
      alert('Введіть користувача та книгу');
      return;
    }

    setLoading(true);
    try {
      let userId = isNaN(userIdentifier)
        ? (await api.get(`/api/user-profiles/get-profile/?email=${userIdentifier}`, {
            headers: { Authorization: `Bearer ${access}` },
          })).data?.id
        : parseInt(userIdentifier);

      let bookId = isNaN(bookIdentifier)
        ? (await api.get(`/api/books/search/?query=${bookIdentifier}`)).data?.[0]?.id
        : parseInt(bookIdentifier);

      if (!userId || !bookId) {
        alert('Не знайдено користувача або книгу');
        return;
      }

      await api.post(
        '/api/bookings/offline/',
        { user: userId, book: bookId },
        { headers: { Authorization: `Bearer ${access}` } }
      );

      alert("Офлайн бронювання створено!");
      setUserIdentifier("");
      setBookIdentifier("");
    } catch (error) {
      setApiError(
        error.response?.data?.message || "Помилка при створенні бронювання"
      );
    } finally {
      setLoading(false);
    }
  };

  if (!user || user.role !== "Librarian") {
    return <Navigate to="/" />;
  }

  return (
    <div className="px-40 flex flex-1 justify-center py-5">
      <div className="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1">
        <div className="flex flex-wrap justify-between gap-3 p-4">
          <p className="text-[#121416] tracking-tight text-[32px] font-bold leading-tight min-w-72">
            Створити офлайн бронювання
          </p>
        </div>
        {apiError && (
          <p className="text-red-500 text-sm px-4 py-2">{apiError}</p>
        )}
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Email користувача"
            type="text"
            name="userIdentifier"
            placeholder="Введіть email або ID користувача"
            value={userIdentifier}
            onChange={handleChange}
            error={errors.userIdentifier}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Назва або ID книги"
            type="text"
            name="bookIdentifier"
            placeholder="Введіть назву або ID книги"
            value={bookIdentifier}
            onChange={handleChange}
            error={errors.bookIdentifier}
          />
        </div>
        <div className="px-4 mt-4">
          <button
            type="submit"
            disabled={loading}
            className="w-full max-w-[200px] bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            onClick={handleSubmit}
          >
            {loading ? "Створення..." : "Створити"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default OfflineReservation; 