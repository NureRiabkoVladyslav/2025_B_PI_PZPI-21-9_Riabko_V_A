import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import FormInput from "../components/FormInput";
import FileUpload from "../components/FileUpload";
import { createBook, uploadBookPhoto } from "../api/books";
import { useAuth } from "../context/AuthContext";

function AddBookPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: "",
    author: "",
    genre: "",
    language: "",
    publisher: "",
    publication_year: "",
    page_count: "",
    description: "",
  });
  const [coverImage, setCoverImage] = useState(null);
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
    setApiError("");
  };

  const handleFileChange = (file) => {
    setCoverImage(file);
    setErrors((prev) => ({ ...prev, coverImage: "" }));
    setApiError("");
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.title) newErrors.title = "Поле обов'язкове";
    if (!formData.author) newErrors.author = "Поле обов'язкове";
    if (!formData.genre) newErrors.genre = "Поле обов'язкове";
    if (!formData.language) newErrors.language = "Поле обов'язкове";
    if (!formData.publisher) newErrors.publisher = "Поле обов'язкове";
    if (!formData.publication_year) newErrors.publication_year = "Поле обов'язкове";
    if (!formData.page_count) newErrors.page_count = "Поле обов'язкове";
    if (!formData.description) newErrors.description = "Поле обов'язкове";
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setApiError("");
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);
    try {
      const bookData = {
        ...formData,
        publication_year: parseInt(formData.publication_year),
        page_count: parseInt(formData.page_count),
      };

      const createdBook = await createBook(bookData);

      if (coverImage) {
        try {
          await uploadBookPhoto(coverImage, createdBook.id);
        } catch (error) {
          console.error('Помилка завантаження фото:', error);
          setApiError("Книгу створено, але виникла помилка при завантаженні фото");
          navigate("/");
          return;
        }
      }

      navigate("/");
    } catch (error) {
      setApiError(
        error.response?.data?.message || "Помилка при створенні книги"
      );
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return <Navigate to="/login" />;
  }

  const userRole = typeof user.role === 'string' ? user.role : user.role?.name;
  const normalizedRole = userRole === 'Administrator' ? 'Admin' : userRole;
  
  if (!["Librarian", "Admin"].includes(normalizedRole)) {
    return <Navigate to="/" />;
  }

  return (
    <div className="px-40 flex flex-1 justify-center py-5">
      <div className="layout-content-container flex flex-col w-full max-w-[960px] py-5">
        <div className="flex flex-wrap justify-between gap-3 p-4">
          <p className="text-[#121416] tracking-tight text-[32px] font-bold leading-tight min-w-72">
            Додати нову книгу
          </p>
        </div>
        {apiError && (
          <p className="text-red-500 text-sm px-4 py-2">{apiError}</p>
        )}
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          {/* Перший ряд в два стовпці */}
          <div className="grid grid-cols-2 gap-6 px-4">
            <div className="flex flex-col gap-4">
          <FormInput
            label="Назва книги"
            type="text"
            name="title"
            placeholder="Введіть назву книги"
            value={formData.title}
            onChange={handleChange}
            error={errors.title}
          />
          <FormInput
            label="Автор"
            type="text"
            name="author"
            placeholder="Введіть автора"
            value={formData.author}
            onChange={handleChange}
            error={errors.author}
          />
          <FormInput
            label="Жанр"
            type="text"
            name="genre"
            placeholder="Введіть жанр"
            value={formData.genre}
            onChange={handleChange}
            error={errors.genre}
          />
          <FormInput
            label="Мова"
            type="text"
            name="language"
            placeholder="Введіть мову"
            value={formData.language}
            onChange={handleChange}
            error={errors.language}
          />
        </div>
            <div className="flex flex-col gap-4">
          <FormInput
            label="Видавництво"
            type="text"
            name="publisher"
            placeholder="Введіть видавництво"
            value={formData.publisher}
            onChange={handleChange}
            error={errors.publisher}
          />
          <FormInput
            label="Рік видання"
            type="number"
            name="publication_year"
            placeholder="Введіть рік видання"
            value={formData.publication_year}
            onChange={handleChange}
            error={errors.publication_year}
            min="1900"
            max={new Date().getFullYear()}
          />
          <FormInput
            label="Кількість сторінок"
            type="number"
            name="page_count"
            placeholder="Введіть кількість сторінок"
            value={formData.page_count}
            onChange={handleChange}
            error={errors.page_count}
            min="1"
          />
              {/* Пустой div для баланса с левой колонкой */}
              <div className="h-[88px]"></div>
            </div>
        </div>

          {/* Опис на всю ширину */}
          <div className="px-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm font-medium text-gray-700">
                Опис
              </label>
              <textarea
            name="description"
            placeholder="Введіть опис книги"
            value={formData.description}
            onChange={handleChange}
                className="w-full h-32 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
              {errors.description && (
                <p className="text-red-500 text-sm">{errors.description}</p>
              )}
            </div>
        </div>

          {/* Завантаження обкладинки */}
          <div className="px-4">
          <FileUpload
            onFileChange={handleFileChange}
            error={errors.coverImage}
          />
        </div>

          {/* Кнопка збереження */}
          <div className="px-4 mt-4">
          <button
              type="submit"
            disabled={loading}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
              {loading ? "Додавання..." : "Додати"}
          </button>
        </div>
        </form>
      </div>
    </div>
  );
}

export default AddBookPage; 