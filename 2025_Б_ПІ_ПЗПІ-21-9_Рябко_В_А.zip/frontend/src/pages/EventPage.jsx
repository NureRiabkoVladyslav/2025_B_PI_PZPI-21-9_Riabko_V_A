import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getEvent } from "../api/events";
import { format } from 'date-fns';
import { uk } from 'date-fns/locale';
import api from "../api";
import { useAuth } from "../context/AuthContext";

function EventPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editedEvent, setEditedEvent] = useState(null);
  const [updateInProgress, setUpdateInProgress] = useState(false);

  const canEditEvent = user && (user.role === 'Administrator' || user.role === 'Librarian');

    const fetchEvent = async () => {
      if (!id) {
        setError("ID події не вказано");
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError("");
        
        const data = await getEvent(id);
        
        if (!data) {
          throw new Error('Подію не знайдено');
        }
        
        setEvent(data);
      setEditedEvent(data);
      } catch (error) {
        setError(error.message || "Помилка при завантаженні події");
        setEvent(null);
      } finally {
        setLoading(false);
      }
    };

  useEffect(() => {
    fetchEvent();
  }, [id]);

  const handleUpdate = async () => {
    try {
      setUpdateInProgress(true);
      setError("");
      
      await api.put(`/api/events/manage/${id}/`, editedEvent);
      await fetchEvent();
      setIsEditing(false);
    } catch (error) {
      setError("Помилка при оновленні події");
    } finally {
      setUpdateInProgress(false);
    }
  };

  const handleInputChange = (field, value) => {
    setEditedEvent(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy 'о' HH:mm", { locale: uk });
    } catch (error) {
      return dateString;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <p>{error}</p>
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded">
          <p>Подію не знайдено</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="md:flex">
            {/* Фото події */}
            <div className="md:w-1/3 p-6">
              <div 
                className="w-full aspect-[3/4] bg-center bg-cover rounded-lg shadow-md"
                style={{
                  backgroundImage: event?.photo
                    ? `url(${event.photo})`
                    : 'url(https://via.placeholder.com/300x400?text=Немає+фото)'
                }}
              />
            </div>
            
            {/* Інформація про подію */}
            <div className="md:w-2/3 p-6">
              {isEditing ? (
                <input
                  type="text"
                  value={editedEvent?.name || ''}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  className="text-3xl font-bold text-gray-900 mb-4 w-full border rounded px-2 py-1"
                />
              ) : (
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                {event?.name}
              </h1>
              )}

              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-semibold text-gray-900">
                    Дата та час
                  </h3>
                  {isEditing ? (
                    <input
                      type="datetime-local"
                      value={editedEvent?.event_date ? new Date(editedEvent.event_date).toISOString().slice(0, 16) : ''}
                      onChange={(e) => handleInputChange('event_date', e.target.value)}
                      className="mt-1 text-gray-600 w-full border rounded px-2 py-1"
                    />
                  ) : (
                  <p className="mt-1 text-gray-600">
                    {event?.event_date ? formatDate(event.event_date) : ''}
                  </p>
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-semibold text-gray-900">
                    Опис
                  </h3>
                  {isEditing ? (
                    <textarea
                      value={editedEvent?.description || ''}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      className="mt-1 text-gray-600 w-full border rounded px-2 py-1 min-h-[100px]"
                    />
                  ) : (
                  <p className="mt-1 text-gray-600 whitespace-pre-line">
                    {event?.description}
                  </p>
                  )}
                </div>

                {/* Кнопки для админа и библиотекаря */}
                {canEditEvent && (
                  <div className="flex gap-4 mt-6">
                    {isEditing ? (
                      <>
                        <button
                          onClick={handleUpdate}
                          disabled={updateInProgress}
                          className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition-all disabled:opacity-50"
                        >
                          {updateInProgress ? 'Збереження...' : 'Зберегти'}
                        </button>
                        <button
                          onClick={() => {
                            setIsEditing(false);
                            setEditedEvent(event); // Reset changes
                          }}
                          className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-all"
                        >
                          Скасувати
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => setIsEditing(true)}
                          className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-all"
                        >
                          Редагувати
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm('Ви впевнені, що хочете видалити цю подію?')) {
                              api.delete(`/api/events/manage/${id}/`)
                                .then(() => navigate('/'))
                                .catch(() => setError('Помилка при видаленні події'));
                            }
                          }}
                          className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition-all"
                        >
                          Видалити
                        </button>
                      </>
                    )}
                  </div>
                )}

                {error && (
                  <div className="mt-4">
                    <p className="text-red-500 text-sm">{error}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default EventPage; 