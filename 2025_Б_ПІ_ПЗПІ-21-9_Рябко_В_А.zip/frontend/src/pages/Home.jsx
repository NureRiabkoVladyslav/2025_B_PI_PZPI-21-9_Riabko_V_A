import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import SearchBar from "../components/SearchBar";
import { getEventsList } from "../api/events";
import { getBooksList } from "../api/books";

function Home() {
  const [events, setEvents] = useState([]);
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState({
    events: true,
    books: true
  });
  const [error, setError] = useState({
    events: "",
    books: ""
  });

  const BOOKS_PER_PAGE = 8; 

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const data = await getEventsList();
        setEvents(data);
      } catch (error) {
        setError(prev => ({ ...prev, events: "Помилка при завантаженні подій" }));
      } finally {
        setLoading(prev => ({ ...prev, events: false }));
      }
    };

    const fetchBooks = async () => {
      try {
        const data = await getBooksList();
        setBooks(data);
      } catch (error) {
        setError(prev => ({ ...prev, books: "Помилка при завантаженні книг" }));
      } finally {
        setLoading(prev => ({ ...prev, books: false }));
      }
    };

    fetchEvents();
    fetchBooks();
  }, []);


  useEffect(() => {
    setCurrentPage(1);
  }, [search]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate();
    const monthNominative = date.toLocaleString('uk-UA', { month: 'long' });
    const monthGenitive = monthNominative.replace(/ень$/, 'ня')
                                       .replace(/й$/, 'я')
                                       .replace(/т$/, 'та')
                                       .replace(/ад$/, 'ада')
                                       .replace(/опад$/, 'опада')
                                       .replace(/есень$/, 'есня');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    
    return `${day}-го ${monthGenitive} о ${hours}:${minutes}`;
  };

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(search.toLowerCase()) ||
    book.author.toLowerCase().includes(search.toLowerCase()) ||
    (book.genre && book.genre.toLowerCase().includes(search.toLowerCase()))
  );

  const totalPages = Math.ceil(filteredBooks.length / BOOKS_PER_PAGE);
  const startIndex = (currentPage - 1) * BOOKS_PER_PAGE;
  const paginatedBooks = filteredBooks.slice(startIndex, startIndex + BOOKS_PER_PAGE);

  return (
    <div className="gap-1 px-6 flex flex-1 justify-center py-5">
      <div className="layout-content-container flex flex-col w-80">
        <h2 className="text-[#121416] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
          Майбутні події
        </h2>
        {loading.events ? (
          <div className="text-center py-4">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1978e5] border-r-transparent"></div>
          </div>
        ) : error.events ? (
          <p className="text-red-500 text-sm px-4">{error.events}</p>
        ) : events.length === 0 ? (
          <p className="text-gray-500 text-sm px-4">Немає запланованих подій</p>
        ) : (
          <div className="flex flex-col gap-2 px-4">
            {events.map((event) => (
              <Link
                key={event.id}
                to={`/events/${event.id}`}
                className="block"
              >
                <div
                  className="p-4 bg-white rounded-lg shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
                >
                  <h3 className="text-[#121416] text-base font-bold mb-1">
                    {event.name}
                  </h3>
                  <p className="text-[#637488] text-sm">
                    {formatDate(event.event_date)}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      <div className="layout-content-container flex flex-col max-w-[960px] flex-1">
        <div className="px-4 py-3">
          <SearchBar 
            placeholder="Пошук за назвою, автором або жанром" 
            value={search}
            onChange={setSearch}
          />
        </div>
        <h2 className="text-[#121416] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
          Список книг
        </h2>
        {loading.books ? (
          <div className="text-center py-4">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1978e5] border-r-transparent"></div>
          </div>
        ) : error.books ? (
          <p className="text-red-500 text-sm px-4">{error.books}</p>
        ) : filteredBooks.length === 0 ? (
          <p className="text-gray-500 text-sm px-4">Книг не знайдено</p>
        ) : (
          <div className="p-4">
            <div className="grid grid-cols-4 gap-6">
              {paginatedBooks.map((book) => (
                <Link
                  key={book.id}
                  to={`/books/${book.id}`}
                  className="block transform hover:scale-105 transition-all duration-200"
                >
                  <div
                    className="flex flex-col gap-3 p-4 bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-lg"
                  >
                    <div 
                      className="w-full aspect-[3/4] bg-center bg-cover rounded-lg shadow-sm"
                      style={{
                        backgroundImage: book.photo
                          ? `url(${book.photo})`
                          : 'url(https://via.placeholder.com/200x300?text=Немає+фото)'
                      }}
                    />
                    <div className="space-y-1">
                      <h3 className="text-[#121416] text-base font-bold line-clamp-1">
                        {book.title}
                      </h3>
                      <p className="text-[#637488] text-sm">
                        {book.author}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
            {totalPages > 1 && (
              <div className="flex justify-center items-center mt-8 gap-4">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm"
                >
                  <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  Назад
                </button>
                <div className="flex items-center gap-2">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                    <button
                      key={page}
                      onClick={() => setCurrentPage(page)}
                      className={`w-10 h-10 flex items-center justify-center rounded-lg transition-all duration-200 ${
                        currentPage === page
                          ? 'bg-blue-500 text-white font-medium shadow-md'
                          : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                      }`}
                    >
                      {page}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-sm"
                >
                  Далі
                  <svg className="w-5 h-5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Home; 