import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getActiveBookings, returnBook } from "../api/bookings";

function ActiveReservations() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [returningBookId, setReturningBookId] = useState(null);

  const fetchBookings = async () => {
    try {
      const data = await getActiveBookings();
      setBookings(data);
    } catch (error) {
      setError("Помилка при завантаженні бронювань");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleReturn = async (bookingId) => {
    try {
      setReturningBookId(bookingId);
      await returnBook(bookingId);
      await fetchBookings();
    } catch (error) {
      setError("Помилка при поверненні книги");
    } finally {
      setReturningBookId(null);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('uk-UA', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1978e5] border-r-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 max-w-5xl">
      <h1 className="text-xl font-bold text-[#121416] mb-4">
        Активні бронювання
      </h1>

      {bookings.length === 0 ? (
        <p className="text-gray-500 text-center py-6">
          У вас немає активних бронювань
        </p>
      ) : (
        <div className="grid gap-3">
          {bookings.map((booking) => (
            <div
              key={booking.id}
              className="bg-white rounded-lg shadow-sm p-4"
            >
              <div className="md:flex gap-4">
                {/* Фото книги */}
                <div className="md:w-[140px] mb-4 md:mb-0 flex-shrink-0">
                  <Link to={`/books/${booking.book}`}>
                    <div 
                      className="w-full aspect-[3/4] bg-center bg-cover rounded-lg shadow-sm"
                      style={{
                        backgroundImage: booking.book_photo
                          ? `url(${booking.book_photo})`
                          : 'url(https://via.placeholder.com/140x186?text=Немає+фото)'
                      }}
                    />
                  </Link>
                </div>

                {/* Інформація про бронювання */}
                <div className="flex-1">
                  <Link 
                    to={`/books/${booking.book}`}
                    className="text-lg font-bold text-[#121416] hover:text-[#1978e5] transition-colors"
                  >
                    {booking.book_title}
                  </Link>
                  
                  <div className="grid md:grid-cols-3 gap-x-6 gap-y-2 mt-2">
                    <div>
                      <h3 className="text-xs font-semibold text-[#121416]">
                        Автор
                      </h3>
                      <p className="text-sm text-[#637488]">{booking.book_author}</p>
                    </div>
                    <div>
                      <h3 className="text-xs font-semibold text-[#121416]">
                        Жанр
                      </h3>
                      <p className="text-sm text-[#637488]">{booking.book_genre}</p>
                    </div>
                    <div>
                      <h3 className="text-xs font-semibold text-[#121416]">
                        Мова
                      </h3>
                      <p className="text-sm text-[#637488]">{booking.book_language}</p>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-x-6 gap-y-2 mt-3 pt-3 border-t border-gray-100">
                    <div>
                      <h3 className="text-xs font-semibold text-[#121416]">
                        Дата бронювання
                      </h3>
                      <p className="text-sm text-[#637488]">
                        {formatDate(booking.booking_date)}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-xs font-semibold text-[#121416]">
                        Повернути до
                      </h3>
                      <p className="text-sm text-[#637488]">
                        {formatDate(booking.return_date)}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4">
                    <button
                      onClick={() => handleReturn(booking.id)}
                      disabled={returningBookId === booking.id}
                      className={`bg-green-500 text-white px-4 py-2 rounded-lg transition-all
                        ${returningBookId === booking.id 
                          ? 'opacity-70 cursor-not-allowed'
                          : 'hover:bg-green-600'
                        }`}
                    >
                      {returningBookId === booking.id ? (
                        <span className="flex items-center">
                          <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-white border-r-transparent mr-2"></span>
                          Повертаємо...
                        </span>
                      ) : (
                        'Повернути'
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default ActiveReservations; 