import { useState } from "react";
import { Navigate } from "react-router-dom";
import FormInput from "../components/FormInput";
import { getUserProfile, getUserBookingHistory, deleteUser } from "../api/users";
import { useAuth } from "../context/AuthContext";

function UserLookup() {
  const { user } = useAuth();
  const [email, setEmail] = useState("");
  const [foundUser, setFoundUser] = useState(null);
  const [bookingHistory, setBookingHistory] = useState([]);
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const getStatusText = (status) => {
    const statusMap = {
      'Booked': 'Позичено',
      'Borrowed': 'Видано',
      'Returned': 'Повернено',
      'Cancelled': 'Скасовано',
      'Expired': 'Прострочено'
    };
    return statusMap[status] || status;
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    setApiError("");
    setFoundUser(null);
    setBookingHistory([]);

    if (!email) {
      setErrors({ email: "Поле обов'язкове" });
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      setErrors({ email: "Невірний формат email" });
      return;
    }

    setLoading(true);
    try {
      const [userData, historyData] = await Promise.all([
        getUserProfile(email),
        getUserBookingHistory(email)
      ]);
      setFoundUser(userData);
      setBookingHistory(historyData);
    } catch (error) {
      setApiError("Помилка при пошуку користувача");
      setFoundUser(null);
      setBookingHistory([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Ви впевнені, що хочете видалити цього користувача?"))
      return;

    setDeleting(true);
    try {
      await deleteUser(foundUser.id);
      setFoundUser(null);
      setBookingHistory([]);
      setEmail("");
      alert("Користувача успішно видалено!");
    } catch (error) {
      setApiError("Помилка при видаленні користувача");
    } finally {
      setDeleting(false);
    }
  };

  if (!user) {
    return <Navigate to="/login" />;
  }

  const userRole = user.role === 'Administrator' ? 'Admin' : user.role;
  if (!["Librarian", "Admin"].includes(userRole)) {
    return <Navigate to="/" />;
  }

  return (
    <div className="px-40 flex flex-1 justify-center py-5">
      <div className="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1">
        <div className="flex flex-wrap justify-between gap-3 p-4">
          <p className="text-[#121416] tracking-tight text-[32px] font-bold leading-tight min-w-72">
            Пошук користувача
          </p>
        </div>
        {apiError && (
          <p className="text-red-500 text-sm px-4 py-2">{apiError}</p>
        )}
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Email користувача"
            type="email"
            name="email"
            placeholder="Введіть email користувача"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setErrors({});
              setApiError("");
            }}
            error={errors.email}
          />
        </div>
        <div className="px-4 py-3">
          <button
            className="w-full max-w-[200px] bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            onClick={handleSearch}
            disabled={loading}
          >
            <span className="truncate">{loading ? "Пошук..." : "Знайти"}</span>
          </button>
        </div>
        {foundUser && (
          <div className="flex flex-col gap-4 px-4 py-3">
            <div className="border rounded-lg p-4 shadow-sm">
              <h2 className="text-xl font-semibold mb-4">Інформація про користувача</h2>
              <div className="space-y-2">
                <p><strong>Email:</strong> {foundUser.email}</p>
                <p><strong>Ім'я:</strong> {foundUser.first_name || '-'}</p>
                <p><strong>Прізвище:</strong> {foundUser.last_name || '-'}</p>
                <p><strong>Телефон:</strong> {foundUser.phone_number || '-'}</p>
                <p><strong>Роль:</strong> {foundUser.role?.name || foundUser.role}</p>
              </div>
              {userRole === "Admin" && (
                <button
                  className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#e57373] text-white text-sm font-bold leading-normal tracking-[0.015em] mt-4"
                  onClick={handleDelete}
                  disabled={deleting}
                >
                  <span className="truncate">
                    {deleting ? "Видалення..." : "Видалити користувача"}
                  </span>
                </button>
              )}
            </div>

            {bookingHistory.length > 0 && (
              <div className="border rounded-lg p-4 shadow-sm">
                <h2 className="text-xl font-semibold mb-4">Історія бронювань</h2>
                <div className="space-y-4">
                  {bookingHistory.map((booking) => (
                    <div key={booking.id} className="border-b pb-2">
                      <p><strong>Книга:</strong> {booking.book_title} ({booking.book_author})</p>
                      <p><strong>Жанр:</strong> {booking.book_genre}</p>
                      <p><strong>Мова:</strong> {booking.book_language}</p>
                      <p><strong>Видавництво:</strong> {booking.book_publisher}</p>
                      <p><strong>Статус:</strong> {getStatusText(booking.status)}</p>
                      <p><strong>Дата бронювання:</strong> {new Date(booking.booking_date).toLocaleDateString("uk-UA")}</p>
                      <p><strong>Повернути до:</strong> {new Date(booking.return_date).toLocaleDateString("uk-UA")}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default UserLookup; 