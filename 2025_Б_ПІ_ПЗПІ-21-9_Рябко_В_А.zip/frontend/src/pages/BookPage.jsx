import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getBook } from "../api/books";
import { createBooking } from "../api/bookings";
import api from "../api";
import { useAuth } from "../context/AuthContext";
import { Link } from "react-router-dom";

function BookPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [bookingInProgress, setBookingInProgress] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedBook, setEditedBook] = useState(null);
  const [updateInProgress, setUpdateInProgress] = useState(false);

  const canEditBook = user && (user.role === 'Administrator' || user.role === 'Librarian');
  const canBookBook = user && user.role === 'User';

  const fetchBook = async () => {
    try {
      const data = await getBook(id);
      setBook(data);
      setEditedBook(data);
    } catch (error) {
      setError("Помилка при завантаженні книги");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBook();
  }, [id]);

  const handleUpdate = async () => {
    try {
      setUpdateInProgress(true);
      setError("");
      
      await api.put(`/api/books/manage/${id}/`, editedBook);
      await fetchBook();
      setIsEditing(false);
    } catch (error) {
      setError("Помилка при оновленні книги");
    } finally {
      setUpdateInProgress(false);
    }
  };

  const handleInputChange = (field, value) => {
    setEditedBook(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleBooking = async () => {
    try {
      setBookingInProgress(true);
      await createBooking({ book: id });
      await fetchBook();
      setError("");
      setTimeout(() => {
        navigate('/active-reservations');
      }, 1000);
    } catch (error) {
      setError("Помилка при бронюванні книги");
    } finally {
      setBookingInProgress(false);
    }
  };

  const getStatusText = (status) => {
    const statusMap = {
      'available': 'Доступна',
      'booked': 'Позичено',
      'Booked': 'Позичено',
      'Returned': 'Доступна',
      'Borrowed': 'Видана'
    };
    return statusMap[status] || status;
  };

  const getStatusColor = (status) => {
    const colorMap = {
      'available': 'text-green-600',
      'Booked': 'text-blue-600',
      'Returned': 'text-green-600',
      'Borrowed': 'text-orange-600'
    };
    return colorMap[status] || 'text-red-600';
  };

  const isBookAvailable = (status) => {
    return status === 'available' || status === 'Returned';
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1978e5] border-r-transparent"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-gray-500">Книгу не знайдено</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="md:flex">
          {/* Ліва колонка з фото */}
          <div className="md:w-1/3 p-6">
            <div 
              className="w-full aspect-[3/4] bg-center bg-cover rounded-lg shadow-md"
              style={{
                backgroundImage: book.photo
                  ? `url(${book.photo})`
                  : 'url(https://via.placeholder.com/300x400?text=Немає+фото)'
              }}
            />
          </div>
          
          {/* Права колонка з інформацією */}
          <div className="md:w-2/3 p-6">
            {isEditing ? (
              <input
                type="text"
                value={editedBook?.title || ''}
                onChange={(e) => handleInputChange('title', e.target.value)}
                className="text-3xl font-bold text-[#121416] mb-2 w-full border rounded px-2 py-1"
              />
            ) : (
            <h1 className="text-3xl font-bold text-[#121416] mb-2">
              {book.title}
            </h1>
            )}

            {isEditing ? (
              <input
                type="text"
                value={editedBook?.author || ''}
                onChange={(e) => handleInputChange('author', e.target.value)}
                className="text-xl text-[#637488] mb-6 w-full border rounded px-2 py-1"
              />
            ) : (
            <p className="text-xl text-[#637488] mb-6">
              {book.author}
            </p>
            )}
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <h3 className="text-sm font-semibold text-[#121416] mb-1">
                  Жанр
                </h3>
                {isEditing ? (
                  <input
                    type="text"
                    value={editedBook?.genre || ''}
                    onChange={(e) => handleInputChange('genre', e.target.value)}
                    className="text-[#637488] w-full border rounded px-2 py-1"
                  />
                ) : (
                <p className="text-[#637488]">{book.genre}</p>
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#121416] mb-1">
                  Мова
                </h3>
                {isEditing ? (
                  <input
                    type="text"
                    value={editedBook?.language || ''}
                    onChange={(e) => handleInputChange('language', e.target.value)}
                    className="text-[#637488] w-full border rounded px-2 py-1"
                  />
                ) : (
                <p className="text-[#637488]">{book.language}</p>
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#121416] mb-1">
                  Рік видання
                </h3>
                {isEditing ? (
                  <input
                    type="number"
                    value={editedBook?.publication_year || ''}
                    onChange={(e) => handleInputChange('publication_year', e.target.value)}
                    className="text-[#637488] w-full border rounded px-2 py-1"
                  />
                ) : (
                <p className="text-[#637488]">{book.publication_year}</p>
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#121416] mb-1">
                  Видавництво
                </h3>
                {isEditing ? (
                  <input
                    type="text"
                    value={editedBook?.publisher || ''}
                    onChange={(e) => handleInputChange('publisher', e.target.value)}
                    className="text-[#637488] w-full border rounded px-2 py-1"
                  />
                ) : (
                <p className="text-[#637488]">{book.publisher}</p>
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#121416] mb-1">
                  Кількість сторінок
                </h3>
                {isEditing ? (
                  <input
                    type="number"
                    value={editedBook?.page_count || ''}
                    onChange={(e) => handleInputChange('page_count', e.target.value)}
                    className="text-[#637488] w-full border rounded px-2 py-1"
                  />
                ) : (
                <p className="text-[#637488]">{book.page_count}</p>
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-[#121416] mb-1">
                  Статус
                </h3>
                <p className={`text-[#637488] ${getStatusColor(book.status)}`}>
                  {getStatusText(book.status)}
                </p>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-sm font-semibold text-[#121416] mb-2">
                Опис
              </h3>
              {isEditing ? (
                <textarea
                  value={editedBook?.description || ''}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  className="text-[#637488] w-full border rounded px-2 py-1 min-h-[100px]"
                />
              ) : (
              <p className="text-[#637488] whitespace-pre-line">
                {book.description}
              </p>
              )}
            </div>

            {/* Кнопки для админа и библиотекаря */}
            {canEditBook && (
              <div className="flex gap-4">
                {isEditing ? (
                  <>
                    <button
                      onClick={handleUpdate}
                      disabled={updateInProgress}
                      className="bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600 transition-all disabled:opacity-50"
                    >
                      {updateInProgress ? 'Збереження...' : 'Зберегти'}
                    </button>
                    <button
                      onClick={() => {
                        setIsEditing(false);
                        setEditedBook(book); // Reset changes
                      }}
                      className="bg-gray-500 text-white px-6 py-2 rounded-lg hover:bg-gray-600 transition-all"
                    >
                      Скасувати
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-all"
                    >
                      Редагувати
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm('Ви впевнені, що хочете видалити цю книгу?')) {
                          api.delete(`/api/books/manage/${id}/`)
                            .then(() => navigate('/'))
                            .catch(() => setError('Помилка при видаленні книги'));
                        }
                      }}
                      className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition-all"
                    >
                      Видалити
                    </button>
                  </>
                )}
              </div>
            )}

            {/* Кнопка бронирования только для авторизованных обычных пользователей */}
            {canBookBook && isBookAvailable(book.status) && (
              <button
                onClick={handleBooking}
                disabled={bookingInProgress}
                className={`bg-[#1978e5] text-white px-6 py-2 rounded-lg transition-all
                  ${bookingInProgress 
                    ? 'opacity-70 cursor-not-allowed'
                    : 'hover:bg-[#1461b8]'
                  }`}
              >
                {bookingInProgress ? (
                  <span className="flex items-center">
                    <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-white border-r-transparent mr-2"></span>
                    Бронювання...
                  </span>
                ) : (
                  'Забронювати'
                )}
              </button>
            )}

            {/* Сообщение для неавторизованных пользователей */}
            {!user && isBookAvailable(book.status) && (
              <p className="text-gray-600 mt-4">
                Щоб забронювати книгу, будь ласка, <Link to="/login" className="text-blue-500 hover:underline">увійдіть</Link> або <Link to="/signup" className="text-blue-500 hover:underline">зареєструйтесь</Link>
              </p>
            )}

            {error && (
              <p className="text-red-500 mt-2 text-sm">
                {error}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default BookPage; 