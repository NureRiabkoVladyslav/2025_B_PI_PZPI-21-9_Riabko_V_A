import { useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import FormInput from "../components/FormInput";
import { getSystemSettings, updateSystemSettings } from "../api/system";
import { useAuth } from "../context/AuthContext";

function SystemSettings() {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    default_borrow_days: "",
    start_hour: "",
    weekday_duration_hours: "",
    weekend_duration_hours: "",
  });
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const settings = await getSystemSettings();
        setFormData({
          default_borrow_days: settings.default_borrow_days?.toString() || "",
          start_hour: settings.start_hour?.toString() || "",
          weekday_duration_hours: settings.weekday_duration_hours?.toString() || "",
          weekend_duration_hours: settings.weekend_duration_hours?.toString() || "",
        });
      } catch (error) {
        setApiError("Помилка при завантаженні налаштувань");
      } finally {
        setLoading(false);
      }
    };
    fetchSettings();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
    setApiError("");
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.default_borrow_days) {
      newErrors.default_borrow_days = "Поле обов'язкове";
    } else if (!/^\d+$/.test(formData.default_borrow_days)) {
      newErrors.default_borrow_days = "Введіть число";
    }
    if (!formData.start_hour) {
      newErrors.start_hour = "Поле обов'язкове";
    } else if (!/^\d+$/.test(formData.start_hour) || parseInt(formData.start_hour) < 0 || parseInt(formData.start_hour) > 23) {
      newErrors.start_hour = "Введіть число від 0 до 23";
    }
    if (!formData.weekday_duration_hours) {
      newErrors.weekday_duration_hours = "Поле обов'язкове";
    } else if (!/^\d+$/.test(formData.weekday_duration_hours) || parseInt(formData.weekday_duration_hours) < 1 || parseInt(formData.weekday_duration_hours) > 24) {
      newErrors.weekday_duration_hours = "Введіть число від 1 до 24";
    }
    if (!formData.weekend_duration_hours) {
      newErrors.weekend_duration_hours = "Поле обов'язкове";
    } else if (!/^\d+$/.test(formData.weekend_duration_hours) || parseInt(formData.weekend_duration_hours) < 1 || parseInt(formData.weekend_duration_hours) > 24) {
      newErrors.weekend_duration_hours = "Введіть число від 1 до 24";
    }
    return newErrors;
  };

  const handleSubmit = async (e) => {
    try {
      e.preventDefault();
      setApiError("");
      const validationErrors = validateForm();
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        return;
      }

      setSubmitting(true);
      await updateSystemSettings({
        ...formData,
        default_borrow_days: Number(formData.default_borrow_days),
        start_hour: Number(formData.start_hour),
        weekday_duration_hours: Number(formData.weekday_duration_hours),
        weekend_duration_hours: Number(formData.weekend_duration_hours),
      });
      alert("Налаштування успішно оновлено!");
      setSubmitting(false);
    } catch (error) {
      setApiError(
        error.response?.data?.message || "Помилка при оновленні налаштувань"
      );
      setSubmitting(false);
    }
  };

  if (!user) {
    return <Navigate to="/login" />;
  }

  const userRole = typeof user.role === 'string' ? user.role : user.role?.name;
  const normalizedRole = userRole === 'Administrator' ? 'Admin' : userRole;
  
  if (normalizedRole !== "Admin") {
    return <Navigate to="/" />;
  }

  if (loading) {
    return (
      <div className="text-center py-10">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[#1978e5] border-r-transparent"></div>
      </div>
    );
  }

  return (
    <div className="px-40 flex flex-1 justify-center py-5">
      <div className="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1">
        <div className="flex flex-wrap justify-between gap-3 p-4">
          <p className="text-[#121416] tracking-tight text-[32px] font-bold leading-tight min-w-72">
            Налаштування системи
          </p>
        </div>
        {apiError && (
          <p className="text-red-500 text-sm px-4 py-2">{apiError}</p>
        )}
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Максимальна тривалість позичання (дні)"
            type="number"
            name="default_borrow_days"
            placeholder="Введіть кількість днів"
            value={formData.default_borrow_days}
            onChange={handleChange}
            error={errors.default_borrow_days}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Година початку роботи (0-23)"
            type="number"
            name="start_hour"
            placeholder="Введіть годину початку роботи"
            value={formData.start_hour}
            onChange={handleChange}
            error={errors.start_hour}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Тривалість роботи у будні (години)"
            type="number"
            name="weekday_duration_hours"
            placeholder="Введіть кількість годин"
            value={formData.weekday_duration_hours}
            onChange={handleChange}
            error={errors.weekday_duration_hours}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Тривалість роботи у вихідні (години)"
            type="number"
            name="weekend_duration_hours"
            placeholder="Введіть кількість годин"
            value={formData.weekend_duration_hours}
            onChange={handleChange}
            error={errors.weekend_duration_hours}
          />
        </div>
        <div className="flex px-4 py-3 justify-end">
          <button
            className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#b2cae5] text-[#121416] text-sm font-bold leading-normal tracking-[0.015em]"
            onClick={handleSubmit}
            disabled={submitting}
          >
            <span className="truncate">
              {submitting ? "Оновлення..." : "Зберегти зміни"}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default SystemSettings; 