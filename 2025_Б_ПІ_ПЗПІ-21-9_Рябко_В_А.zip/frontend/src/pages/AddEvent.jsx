import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import FormInput from "../components/FormInput";
import FileUpload from "../components/FileUpload";
import { createEvent, uploadEventPhoto } from "../api/events";
import { useAuth } from "../context/AuthContext";

function AddEvent() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    date: "",
    time: "",
  });
  const [coverImage, setCoverImage] = useState(null);
  const [errors, setErrors] = useState({});
  const [apiError, setApiError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
    setApiError("");
  };

  const handleFileChange = (file) => {
    setCoverImage(file);
    setErrors((prev) => ({ ...prev, coverImage: "" }));
    setApiError("");
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = "Поле обов'язкове";
    if (!formData.description) newErrors.description = "Поле обов'язкове";
    if (!formData.date) newErrors.date = "Поле обов'язкове";
    if (!formData.time) newErrors.time = "Поле обов'язкове";
    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setApiError("");
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setLoading(true);
    try {
      const dateTime = new Date(`${formData.date}T${formData.time}`);

      const eventData = {
        name: formData.name,
        description: formData.description,
        event_date: dateTime.toISOString(),
      };

      const createdEvent = await createEvent(eventData);

      if (coverImage && createdEvent.id) {
        try {
          const photoFormData = new FormData();
          photoFormData.append('image', coverImage);
          photoFormData.append('event_id', createdEvent.id);
          
          await uploadEventPhoto(photoFormData);
        } catch (error) {
          console.error('Помилка завантаження фото:', error);
          setApiError("Подію створено, але виникла помилка при завантаженні фото");
          navigate("/");
          return;
        }
      }

      navigate("/");
    } catch (error) {
      setApiError(
        error.response?.data?.message || "Помилка при створенні події"
      );
    } finally {
      setLoading(false);
    }
  };

  const userRole = user?.role === 'Administrator' ? 'Admin' : user?.role;
  if (!user || !["Librarian", "Admin"].includes(userRole)) {
    return <Navigate to="/" />;
  }

  return (
    <div className="px-40 flex flex-1 justify-center py-5">
      <div className="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1">
        <div className="flex flex-wrap justify-between gap-3 p-4">
          <p className="text-[#121416] tracking-tight text-[32px] font-bold leading-tight min-w-72">
            Додати нову подію
          </p>
        </div>
        {apiError && (
          <p className="text-red-500 text-sm px-4 py-2">{apiError}</p>
        )}
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Назва події"
            type="text"
            name="name"
            placeholder="Введіть назву події"
            value={formData.name}
            onChange={handleChange}
            error={errors.name}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Опис"
            type="textarea"
            name="description"
            placeholder="Введіть опис події"
            value={formData.description}
            onChange={handleChange}
            error={errors.description}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Дата"
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            error={errors.date}
          />
        </div>
        <div className="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
          <FormInput
            label="Час"
            type="time"
            name="time"
            value={formData.time}
            onChange={handleChange}
            error={errors.time}
          />
        </div>
        <div className="flex flex-col p-4">
          <FileUpload
            onFileChange={handleFileChange}
            error={errors.coverImage}
            label="Фото афіші"
            dragText="Перетягніть фото афіші сюди або клікніть для вибору"
          />
        </div>
        <div className="px-4 mt-4">
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            onClick={handleSubmit}
          >
            {loading ? "Додавання..." : "Додати"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default AddEvent; 