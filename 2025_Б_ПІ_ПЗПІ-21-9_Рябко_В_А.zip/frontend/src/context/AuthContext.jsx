import { createContext, useContext, useState, useEffect } from "react";
import {
  login as apiLogin,
  signup as apiSignup,
  getUserProfile,
} from "../api/auth";

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("authToken");
    if (token) {
      getUserProfile()
        .then((userData) => {
          setUser(userData);
        })
        .catch(() => {
          localStorage.removeItem("authToken");
        })
        .finally(() => {
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  const login = async (credentials) => {
    const { token, user: userData } = await apiLogin(credentials);
    localStorage.setItem("authToken", token);
    setUser(userData);
    return userData;
  };

  const signup = async (userData) => {
    const { token, user: newUser } = await apiSignup(userData);
    localStorage.setItem("authToken", token);
    setUser(newUser);
    return newUser;
  };

  const logout = () => {
    localStorage.removeItem("authToken");
    setUser(null);
  };

  const value = {
    user,
    loading,
    login,
    signup,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
