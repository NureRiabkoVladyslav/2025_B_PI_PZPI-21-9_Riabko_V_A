import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div>Loading...</div>;
  }

  if (allowedRoles && !user) {
    return <Navigate to="/login" />;
  }

  if (user && allowedRoles) {
    const userRole = user.role === 'Administrator' ? 'Admin' : user.role;
    if (!allowedRoles.includes(userRole)) {
      return <Navigate to="/" />;
    }
  }

  return children;
};

export default ProtectedRoute; 