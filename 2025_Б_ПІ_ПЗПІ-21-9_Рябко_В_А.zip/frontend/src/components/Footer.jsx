import { useState, useEffect } from "react";
import { getSystemSettings } from "../api/system";

const DEFAULT_SETTINGS = {
  start_hour: 9,
  weekday_duration_hours: 8,
  weekend_duration_hours: 4
};

const Footer = () => {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const data = await getSystemSettings();
        if (data) {
          setSettings(data);
        }
      } catch (error) {
        console.log("Using default system settings");
      }
    };
    fetchSettings();
  }, []);

  const formatTime = (hour) => {
    return hour.toString().padStart(2, '0') + ':00';
  };

  const getWorkingHours = (startHour, duration) => {
    const endHour = startHour + duration;
    return `${formatTime(startHour)} - ${formatTime(endHour)}`;
  };

  const weekdayHours = getWorkingHours(settings.start_hour, settings.weekday_duration_hours);
  const weekendHours = getWorkingHours(settings.start_hour, settings.weekend_duration_hours);

  return (
    <footer className="bg-gray-800 text-white py-8 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-between">
          <div className="w-full md:w-1/3 mb-6 md:mb-0">
            <h3 className="text-xl font-bold mb-4">LibSystem</h3>
            <p className="text-gray-400">
              Ми чекаємо вас у нашій бібліотеці
            </p>
          </div>
          <div className="w-full md:w-1/3 mb-6 md:mb-0">
            <h3 className="text-xl font-bold mb-4">Контакти</h3>
            <p className="text-gray-400">Email: info@libsystem.com</p>
            <p className="text-gray-400">Телефон: +380 (44) 123-45-67</p>
            <p className="text-gray-400">Адреса: вул. Бібліотечна, 1, Київ</p>
          </div>
          <div className="w-full md:w-1/3">
            <h3 className="text-xl font-bold mb-4">Години роботи</h3>
            <p className="text-gray-400">Пн-Пт: {weekdayHours}</p>
            <p className="text-gray-400">Сб-Нд: {weekendHours}</p>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © {new Date().getFullYear()} LibSystem. Всі права захищені.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer; 