import React from 'react';
import { Link } from 'react-router-dom';

const Header = ({ user }) => {
  const isAdmin = user?.role === 'Administrator' || user?.role === 'Admin';
  const isLibrarian = user?.role === 'Librarian';
  const isAdminOrLibrarian = isAdmin || isLibrarian;

  return (
    <header className="bg-green-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link to="/" className="font-bold text-xl">
              📚 Бібліотека
            </Link>

            <nav className="hidden md:flex space-x-4">
              <Link to="/" className="hover:text-green-200">
                🏠 Головна
              </Link>
              <Link to="/events" className="hover:text-green-200">
                🎉 Події
              </Link>
              {user && (
                <>
                  <Link to="/active-reservations" className="hover:text-green-200">
                    📖 Активні бронювання
                  </Link>
                  <Link to="/booking-history" className="hover:text-green-200">
                    📜 Історія бронювань
                  </Link>
                  <Link to="/events/my" className="hover:text-green-200">
                    🎯 Мої події
                  </Link>
                </>
              )}
              {isAdminOrLibrarian && (
                <>
                  <Link to="/add-book" className="hover:text-green-200">
                    ➕ Додати книгу
                  </Link>
                  <Link to="/offline-reservations" className="hover:text-green-200">
                    📝 Оффлайн бронювання
                  </Link>
                  <Link to="/add-event" className="hover:text-green-200">
                    🎈 Додати подію
                  </Link>
                </>
              )}
              {isAdmin && (
                <>
                  <Link to="/users" className="hover:text-green-200">
                    👥 Користувачі
                  </Link>
                  <Link to="/system-settings" className="hover:text-green-200">
                    ⚙️ Налаштування
                  </Link>
                </>
              )}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <span className="text-sm">
                  {user.email} ({user.role})
                </span>
                <Link
                  to="/login"
                  onClick={() => localStorage.removeItem('access')}
                  className="bg-red-500 hover:bg-red-600 px-4 py-2 rounded"
                >
                  Вийти
                </Link>
              </div>
            ) : (
              <div className="space-x-4">
                <Link
                  to="/login"
                  className="bg-green-500 hover:bg-green-600 px-4 py-2 rounded"
                >
                  Увійти
                </Link>
                <Link
                  to="/register"
                  className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded"
                >
                  Зареєструватися
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header; 