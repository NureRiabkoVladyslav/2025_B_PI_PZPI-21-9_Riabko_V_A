import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const Header = ({ isAuthPage }) => {
  const { user, logout } = useAuth();

  if (isAuthPage) return null;

  const renderMainMenu = () => {
    if (!user) return null;

    switch (user.role) {
      case 'User':
        return (
          <>
            <Link to="/active-reservations" className="text-gray-600 hover:text-gray-800">
              Активні бронювання
            </Link>
            <Link to="/booking-history" className="text-gray-600 hover:text-gray-800">
              Історія бронювань
            </Link>
            <Link to="/profile" className="text-gray-600 hover:text-gray-800">
              Мій профіль
            </Link>
          </>
        );
      case 'Librarian':
        return (
          <>
            <Link to="/add-book" className="text-gray-600 hover:text-gray-800">
              Додати книгу
            </Link>
            <Link to="/add-event" className="text-gray-600 hover:text-gray-800">
              Додати подію
            </Link>
            <Link to="/offline-reservations" className="text-gray-600 hover:text-gray-800">
              Офлайн бронювання
            </Link>
            <Link to="/users" className="text-gray-600 hover:text-gray-800">
              Перегляд користувачів
            </Link>
            <Link to="/profile" className="text-gray-600 hover:text-gray-800">
              Мій профіль
            </Link>
          </>
        );
      case 'Administrator':
        return (
          <>
            <Link to="/add-book" className="text-gray-600 hover:text-gray-800">
              Додати книгу
            </Link>
            <Link to="/add-event" className="text-gray-600 hover:text-gray-800">
              Додати подію
            </Link>
            <Link to="/users" className="text-gray-600 hover:text-gray-800">
              Перегляд користувачів
            </Link>
            <Link to="/system-settings" className="text-gray-600 hover:text-gray-800">
              Системні параметри
            </Link>
            <Link to="/profile" className="text-gray-600 hover:text-gray-800">
              Мій профіль
            </Link>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <header className="bg-white shadow">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-4 text-[#121416]">
              <div className="w-8 h-8">
                <svg viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M250 50C142.157 50 50 142.157 50 250C50 357.843 142.157 450 250 450C357.843 450 450 357.843 450 250C450 142.157 357.843 50 250 50ZM250 400C169.543 400 100 330.457 100 250C100 169.543 169.543 100 250 100C330.457 100 400 169.543 400 250C400 330.457 330.457 400 250 400Z" fill="currentColor"/>
                  <path d="M200 150H300V350H200C172.386 350 150 327.614 150 300V200C150 172.386 172.386 150 200 150ZM250 175H200C186.193 175 175 186.193 175 200V300C175 313.807 186.193 325 200 325H250V175Z" fill="currentColor"/>
                </svg>
              </div>
              <h2 className="text-[#121416] text-lg font-bold leading-tight tracking-[-0.015em]">
                LibSystem
              </h2>
            </Link>
            <div className="flex items-center space-x-4">
              {renderMainMenu()}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {user ? (
              <button
                onClick={logout}
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
              >
                Вийти
              </button>
            ) : (
              <>
                <Link
                  to="/login"
                  className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
                >
                  Увійти
                </Link>
                <Link
                  to="/signup"
                  className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
                >
                  Зареєструватися
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
};

export default Header; 