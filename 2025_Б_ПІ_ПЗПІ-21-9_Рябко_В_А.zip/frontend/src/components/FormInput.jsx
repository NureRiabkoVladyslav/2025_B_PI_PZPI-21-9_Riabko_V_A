const FormInput = ({
  label,
  type,
  name,
  placeholder,
  value,
  onChange,
  error,
  options,
}) => {
  const baseInputClasses =
    "form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-[#111418] focus:outline-0 focus:ring-0 border border-[#dce0e5] bg-white focus:border-[#dce0e5] h-14 placeholder:text-[#637488] p-[15px] text-base font-normal leading-normal";

  const renderInput = () => {
    switch (type) {
      case "textarea":
        return (
          <textarea
            name={name}
            placeholder={placeholder}
            value={value}
            onChange={onChange}
            className={`${baseInputClasses} h-32`}
          />
        );
      case "select":
        return (
          <select
            name={name}
            value={value}
            onChange={onChange}
            className={baseInputClasses}
          >
            {options.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        );
      default:
        return (
          <input
            type={type}
            name={name}
            placeholder={placeholder}
            value={value}
            onChange={onChange}
            className={baseInputClasses}
          />
        );
    }
  };

  return (
    <label className="flex flex-col min-w-40 flex-1">
      <p className="text-[#111418] text-base font-medium leading-normal pb-2">
        {label}
      </p>
      {renderInput()}
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </label>
  );
};

export default FormInput; 