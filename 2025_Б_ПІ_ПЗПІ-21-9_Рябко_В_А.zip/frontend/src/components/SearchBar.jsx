const SearchBar = ({ placeholder, value, onChange }) => {
  return (
    <div className="relative">
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-12 px-4 pr-12 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
      />
      <button className="absolute right-4 top-1/2 transform -translate-y-1/2">
        <svg
          width="20"
          height="20"
          viewBox="0 0 20 20"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M19.0711 17.6569L13.8995 12.4853C15.0165 11.0494 15.6667 9.27841 15.6667 7.33333C15.6667 3.28731 12.3794 0 8.33333 0C4.28731 0 1 3.28731 1 7.33333C1 11.3794 4.28731 14.6667 8.33333 14.6667C10.2784 14.6667 12.0494 14.0165 13.4853 12.8995L18.6569 18.0711C18.8442 18.2584 19.0911 18.3521 19.3381 18.3521C19.585 18.3521 19.8319 18.2584 20.0192 18.0711C20.3939 17.6964 20.3939 17.0316 20.0192 16.6569L19.0711 17.6569ZM8.33333 12.6667C5.38731 12.6667 3 10.2794 3 7.33333C3 4.38731 5.38731 2 8.33333 2C11.2794 2 13.6667 4.38731 13.6667 7.33333C13.6667 10.2794 11.2794 12.6667 8.33333 12.6667Z"
            fill="#637488"
          />
        </svg>
      </button>
    </div>
  );
};

export default SearchBar; 