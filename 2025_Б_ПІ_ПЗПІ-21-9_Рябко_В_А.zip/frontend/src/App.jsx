import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import EventPage from "./pages/EventPage";
import AddEvent from "./pages/AddEvent";
import BookingHistory from "./pages/BookingHistory";
import ActiveReservations from "./pages/ActiveReservations";
import OfflineReservation from "./pages/OfflineReservation";
import Profile from "./pages/Profile";
import SystemSettings from "./pages/SystemSettings";
import UserLookup from "./pages/UserLookup";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import BookPage from "./pages/BookPage";
import AddBookPage from './pages/AddBookPage';

function AppContent() {
  const location = useLocation();
  const isAuthPage = ["/login", "/signup"].includes(location.pathname);

  return (
    <div className="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden">
      <div className="layout-container flex h-full grow flex-col">
        <Header isAuthPage={isAuthPage} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/books/:id" element={<BookPage />} />
          <Route
            path="/add-book"
            element={
              <ProtectedRoute allowedRoles={["Librarian", "Admin"]}>
                <AddBookPage />
              </ProtectedRoute>
            }
          />
          <Route path="/events/:id" element={<EventPage />} />
          <Route
            path="/add-event"
            element={
              <ProtectedRoute allowedRoles={["Librarian", "Admin"]}>
                <AddEvent />
              </ProtectedRoute>
            }
          />
          <Route
            path="/booking-history"
            element={
              <ProtectedRoute allowedRoles={["User", "Librarian", "Admin"]}>
                <BookingHistory />
              </ProtectedRoute>
            }
          />
          <Route
            path="/active-reservations"
            element={
              <ProtectedRoute allowedRoles={["User", "Librarian", "Admin"]}>
                <ActiveReservations />
              </ProtectedRoute>
            }
          />
          <Route
            path="/offline-reservations"
            element={
              <ProtectedRoute allowedRoles={["Librarian"]}>
                <OfflineReservation />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute allowedRoles={["User", "Librarian", "Admin"]}>
                <Profile />
              </ProtectedRoute>
            }
          />
          <Route
            path="/system-settings"
            element={
              <ProtectedRoute allowedRoles={["Admin"]}>
                <SystemSettings />
              </ProtectedRoute>
            }
          />
          <Route
            path="/users"
            element={
              <ProtectedRoute allowedRoles={["Librarian", "Admin"]}>
                <UserLookup />
              </ProtectedRoute>
            }
          />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
        </Routes>
        <Footer />
      </div>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}

export default App; 