import api from './index';
import { API_URL } from './config';

export const createBook = async (bookData) => {
  const response = await api.post('/api/books/manage/', bookData);
  return response.data;
};

export const uploadBookPhoto = async (file, bookId) => {
  const formData = new FormData();
  formData.append('photo', file);
  formData.append('book_id', bookId);
  
  const token = localStorage.getItem('authToken');
  if (!token) {
    throw new Error('Не авторизований');
  }

  const response = await api.post('/api/photos/upload/', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
      'Authorization': `Bearer ${token}`,
    },
    withCredentials: true,
  });
  
  return response.data;
};

export const getBook = async (id) => {
  try {
    const response = await api.get(`/api/books/manage/${id}/`);
    return response.data;
  } catch (error) {
    throw new Error('Помилка при отриманні інформації про книгу');
  }
};

export const updateBook = async (id, bookData) => {
  const response = await api.patch(`/books/${id}/`, bookData);
  return response.data;
};

export const deleteBook = async (id) => {
  const response = await api.delete(`/books/${id}/`);
  return response.data;
};

export const getBooks = async (params) => {
  const response = await api.get('/books/', { params });
  return response.data;
};

export const getBooksList = async () => {
  try {
    const response = await api.get('/api/books/list/');
    return response.data;
  } catch (error) {
    throw new Error('Помилка при отриманні списку книг');
  }
}; 