import api from './api';

export const login = async (credentials) => {
  try {
    const tokenResponse = await api.post('/api/token/', credentials);
    if (tokenResponse.data.access) {
      localStorage.setItem('authToken', tokenResponse.data.access);
    }

    const userResponse = await api.get('/api/user-profiles/me/');

    return {
      token: tokenResponse.data.access,
      user: userResponse.data
    };
  } catch (error) {
    throw error;
  }
};

export const signup = async (userData) => {
  try {
    if (!userData.email || !userData.password) {
      throw new Error('Email та пароль обов\'язкові');
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userData.email)) {
      throw new Error('Невірний формат email');
    }

    if (userData.password.length < 6) {
      throw new Error('Пароль повинен містити мінімум 6 символів');
    }

    const response = await api.post('/api/users/register/', userData);
    
    if (response.data.token) {
      localStorage.setItem('authToken', response.data.token);
    }
    
    return response.data;
  } catch (error) {
    if (error.message) {
      throw error;
    }
    throw new Error(error.response?.data?.message || 'Помилка реєстрації. Спробуйте ще раз.');
  }
};

export const getUserProfile = async () => {
  try {
    const response = await api.get('/api/user-profiles/me/');
    return response.data;
  } catch (error) {
    throw new Error('Помилка отримання профілю користувача');
  }
};

export const updateUserProfile = async (data) => {
  try {
    const response = await api.patch('/api/user-profiles/me/', data);
    return response.data;
  } catch (error) {
    throw new Error('Помилка оновлення профілю');
  }
}; 