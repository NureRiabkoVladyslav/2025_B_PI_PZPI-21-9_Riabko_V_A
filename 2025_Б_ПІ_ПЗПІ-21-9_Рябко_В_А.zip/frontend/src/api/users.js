import api from './api';

export const getUserProfile = async (email) => {
  const response = await api.get(`/api/user-profiles/get-profile/?email=${encodeURIComponent(email)}`);
  return response.data;
};

export const getUserBookingHistory = async (email) => {
  const response = await api.get(`/api/bookings/user/history/?email=${encodeURIComponent(email)}`);
  return response.data;
};

export const deleteUser = async (userId) => {
  const response = await api.delete(`/api/users/${userId}/delete/`);
  return response.data;
}; 