import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8000",
  headers: {
    "Content-Type": "application/json",
    "Accept": "application/json",
  },
  withCredentials: true,
});

const publicRoutes = [
  '/api/books/list/',
  '/api/events/list/',
  '/api/books/manage/',
  '/api/system/settings/'
];

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("authToken");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error);
    
    if (!error.response) {
      return Promise.reject(new Error("Помилка мережі. Перевірте з'єднання з сервером."));
    }

    const errorMessage = error.response?.data?.message || error.response?.data?.error || "Сталася помилка. Спробуйте ще раз.";

    if (error.response.status === 401) {
      localStorage.removeItem("authToken");
      const isPublicRoute = publicRoutes.some(route => error.config.url.includes(route));
      if (!isPublicRoute && window.location.pathname !== '/login') {
        window.location.href = "/login";
      }
    }

    return Promise.reject(new Error(errorMessage));
  }
);

export default api;
