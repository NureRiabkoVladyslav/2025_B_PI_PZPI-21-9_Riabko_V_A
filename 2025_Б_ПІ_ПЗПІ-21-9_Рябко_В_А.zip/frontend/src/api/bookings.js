import api from './api';

export const createBooking = async (bookData) => {
  try {
    const response = await api.post('/api/bookings/create/', bookData);
    return response.data;
  } catch (error) {
    throw new Error('Помилка при бронюванні книги');
  }
};

export const getMyBookings = async () => {
  try {
    const response = await api.get('/api/bookings/my/');
    return response.data;
  } catch (error) {
    throw new Error('Помилка при отриманні історії бронювань');
  }
};

export const getActiveReservations = async () => {
  try {
    const response = await api.get('/api/bookings/active/');
    return response.data;
  } catch (error) {
    throw new Error('Помилка при отриманні активних бронювань');
  }
};

export const returnBook = async (bookingId) => {
  const response = await api.post(`/api/bookings/${bookingId}/return/`);
  return response.data;
};

export const cancelBooking = async (bookingId) => {
  const response = await api.post(`/bookings/${bookingId}/cancel/`);
  return response.data;
};

export const createOfflineBooking = async (bookingData) => {
  const response = await api.post('/api/bookings/create/offline/', {
    book: bookingData.bookId,
    user_email: bookingData.userEmail,
  });
  return response.data;
};

export const getActiveBookings = async () => {
  const response = await api.get('/api/bookings/active/');
  return response.data;
}; 