import api from './api';

export const getSystemSettings = async () => {
  const response = await api.get('/api/system/settings/');
  return response.data;
};

export const updateSystemSettings = async (settingsData) => {
  const response = await api.patch('/api/system/settings/', settingsData);
  return response.data;
}; 