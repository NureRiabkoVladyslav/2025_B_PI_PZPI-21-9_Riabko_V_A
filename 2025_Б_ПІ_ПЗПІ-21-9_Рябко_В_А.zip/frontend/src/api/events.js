import api from './index';
import { API_URL } from './config';

export const createEvent = async (eventData) => {
  const response = await api.post('/api/events/manage/', eventData);
  return response.data;
};

export const uploadEventPhoto = async (formData) => {
  const token = localStorage.getItem('authToken');
  if (!token) {
    throw new Error('Не авторизований');
  }

  const response = await api.post('/api/events/upload-photo/', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
      'Authorization': `Bearer ${token}`,
    },
    withCredentials: true,
  });
  
  return response.data;
};

export const getEvent = async (id) => {
  console.log('Making API request to:', `${API_URL}/api/events/manage/${id}/`);
  
  try {
    const response = await fetch(`${API_URL}/api/events/manage/${id}/`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    console.log('Response status:', response.status);

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('Подію не знайдено');
      }
      throw new Error(`Помилка сервера: ${response.status}`);
    }

    const data = await response.json();
    console.log('Response data:', data);
    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

export const updateEvent = async (id, eventData) => {
  const response = await api.patch(`/events/${id}/`, eventData);
  return response.data;
};

export const deleteEvent = async (id) => {
  const response = await api.delete(`/events/${id}/`);
  return response.data;
};

export const getEvents = async (params) => {
  const response = await api.get('/events/', { params });
  return response.data;
};

export const getEventsList = async () => {
  try {
    const response = await api.get('/api/events/list/');
    return response.data;
  } catch (error) {
    throw new Error('Помилка при отриманні списку подій');
  }
}; 