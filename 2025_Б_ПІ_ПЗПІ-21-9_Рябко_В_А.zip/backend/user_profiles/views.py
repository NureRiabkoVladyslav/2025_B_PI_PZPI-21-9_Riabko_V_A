from rest_framework import generics, permissions
from .models import UserProfile
from .serializers import UserProfileSerializer, UserProfileShortSerializer  # 💥 добавил импорт
from rest_framework.permissions import IsAuthenticated
from rest_framework.exceptions import NotFound
from users.models import User
from .models import UserProfile
from .serializers import FullUserContactSerializer

class UserProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user.profile

class AllUserContactsView(generics.ListAPIView):
    queryset = UserProfile.objects.select_related('user')
    serializer_class = UserProfileShortSerializer
    permission_classes = [permissions.IsAuthenticated]

class UserContactByIdOrEmailView(generics.RetrieveAPIView):
    serializer_class = FullUserContactSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        email = self.request.query_params.get("email")
        user_id = self.request.query_params.get("id")

        if email:
            try:
                user = User.objects.get(email=email)
            except User.DoesNotExist:
                raise NotFound("Користувача з таким email не знайдено")
        elif user_id:
            try:
                user = User.objects.get(id=user_id)
            except User.DoesNotExist:
                raise NotFound("Користувача з таким ID не знайдено")
        else:
            raise NotFound("Необхідно вказати або email, або id")

        try:
            return user.profile
        except UserProfile.DoesNotExist:
            raise NotFound("Профіль користувача не знайдено")