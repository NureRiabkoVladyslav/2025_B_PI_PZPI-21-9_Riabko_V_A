from django.urls import path
from .views import UserProfileView, AllUserContactsView, UserContactByIdOrEmailView


urlpatterns = [
    path('me/', UserProfileView.as_view(), name='my-profile'),
    path('contacts/', AllUserContactsView.as_view(), name='user-contacts'),
    path('get-profile/', UserContactByIdOrEmailView.as_view(), name='get-user-contact'),
]