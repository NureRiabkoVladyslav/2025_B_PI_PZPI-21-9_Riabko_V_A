from rest_framework import serializers
from .models import Booking
from system_settings.models import SystemSettings
from datetime import timedelta
from django.utils import timezone
from books.serializers import BookSerializer
from rest_framework.exceptions import ValidationError

class CreateBookingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Booking
        fields = ['book'] 

    def create(self, validated_data):
        user = self.context['request'].user
        book = validated_data['book']
        settings = SystemSettings.objects.first()
        borrow_days = settings.default_borrow_days if settings else 14
        existing_booking = Booking.objects.filter(book=book, status='Booked').exists()
        if existing_booking:
            raise ValidationError({'book': ['Ця книга вже заброньована іншим користувачем.']})

        # Create the booking
        booking = Booking.objects.create(
            user=user,
            book=book,
            status='Booked',
            return_date=timezone.now() + timedelta(days=borrow_days)
        )

        # Update the book's status to 'booked'
        book.status = 'booked'
        book.save()

        return booking

class BookingSerializer(serializers.ModelSerializer):
    user_email = serializers.EmailField(source='user.email', read_only=True)
    book_title = serializers.CharField(source='book.title', read_only=True)
    book_author = serializers.CharField(source='book.author', read_only=True)
    book_genre = serializers.CharField(source='book.genre', read_only=True)
    book_language = serializers.CharField(source='book.language', read_only=True)
    book_publisher = serializers.CharField(source='book.publisher', read_only=True)
    book_page_count = serializers.IntegerField(source='book.page_count', read_only=True)
    book_photo = serializers.SerializerMethodField()

    class Meta:
        model = Booking
        fields = [
            'id',
            'user',
            'user_email',
            'book',
            'book_title',
            'book_author',
            'book_genre',
            'book_language',
            'book_publisher',
            'book_page_count',
            'book_photo',
            'status',
            'booking_date',
            'return_date'
        ]
        read_only_fields = [
            'user', 'user_email', 'book', 'book_title',
            'book_author', 'book_genre', 'book_language',
            'book_publisher', 'book_page_count', 'book_photo',
            'booking_date', 'return_date'
        ]

    def get_book_photo(self, obj):
        request = self.context.get('request')
        if obj.book.photo and obj.book.photo.image:
            if request:
                return request.build_absolute_uri(obj.book.photo.image.url)
            return obj.book.photo.image.url
        return None