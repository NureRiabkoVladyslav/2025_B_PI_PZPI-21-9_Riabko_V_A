from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.utils import timezone
from datetime import datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions, status
from users.models import User
from bookings.models import Booking
from bookings.serializers import BookingSerializer

from .models import Booking
from .serializers import BookingSerializer, CreateBookingSerializer


class CreateBookingView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = CreateBookingSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        booking = serializer.save()

        response_serializer = BookingSerializer(booking, context={'request': request})
        return Response(response_serializer.data, status=status.HTTP_201_CREATED)


class BookingHistoryByIdOrEmail(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user_id = request.query_params.get('id')
        email = request.query_params.get('email')

        if not user_id and not email:
            return Response({'detail': 'Потрібно вказати або id, або email'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            if user_id:
                user = User.objects.get(id=user_id)
            else:
                user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'detail': 'Користувача не знайдено'}, status=status.HTTP_404_NOT_FOUND)

        bookings = Booking.objects.filter(user=user).order_by('-booking_date')
        serializer = BookingSerializer(bookings, many=True)
        return Response(serializer.data)

class UpcomingReturnsView(generics.ListAPIView):
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Booking.objects.filter(
            user=self.request.user,
            status='Booked',
            return_date__isnull=False,
            return_date__gte=datetime.now()
        ).order_by('return_date')


class OfflineBookingView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        book_id = request.data.get('book')
        user_id = request.data.get('user')

        booking = Booking.objects.create(
            user_id=user_id,
            book_id=book_id,
            status='Booked'
        )

        book = booking.book
        book.status = 'booked'
        book.save()

        return Response({'id': booking.id}, status=status.HTTP_201_CREATED)


class RegisterReturnView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        try:
            booking = Booking.objects.get(id=pk, status='Booked')
            booking.status = 'Returned'
            booking.return_date = timezone.now()
            booking.save()
            book = booking.book
            book.status = 'available'
            book.save()

            return Response({'detail': 'Книгу повернено'}, status=status.HTTP_200_OK)
        except Booking.DoesNotExist:
            return Response({'detail': 'Бронювання не знайдено'}, status=status.HTTP_404_NOT_FOUND)


class UserBookingHistoryView(generics.ListAPIView):
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user_id = self.kwargs['user_id']
        current_user = self.request.user

        if current_user.id == user_id or current_user.role.name in ['Librarian', 'Administrator']:
            return Booking.objects.filter(user_id=user_id).order_by('-booking_date')

        return Booking.objects.none()


class MyBookingsView(generics.ListAPIView):
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user).order_by('-booking_date')

class ActiveBookingsView(generics.ListAPIView):
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Booking.objects.filter(user=self.request.user, status='Booked').order_by('-booking_date')
