from django.urls import path
from .views import (
    MyBookingsView, CreateBookingView, UpcomingReturnsView, RegisterReturnView,
    OfflineBookingView, UserBookingHistoryView, ActiveBookingsView
)
from .views import BookingHistoryByIdOrEmail

urlpatterns = [
    path('my/', MyBookingsView.as_view(), name='my-bookings'),
    path('create/', CreateBookingView.as_view(), name='create-booking'),
    path('returns/upcoming/', UpcomingReturnsView.as_view(), name='upcoming-returns'),
    path('<int:pk>/return/', RegisterReturnView.as_view(), name='register-return'),
    path('offline/', OfflineBookingView.as_view(), name='offline-booking'),
    path('user/<int:user_id>/history/', UserBookingHistoryView.as_view(), name='user-booking-history'),
    path('active/', ActiveBookingsView.as_view(), name='active-bookings'), 
    path('user/history/', BookingHistoryByIdOrEmail.as_view(), name='user-booking-history'),
]
