from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import BookListView, BookSearchView, BookViewSet

router = DefaultRouter()
router.register(r'manage', BookViewSet, basename='book-manage')

urlpatterns = [
    path('list/', BookListView.as_view(), name='book-list'),
    path('search/', BookSearchView.as_view(), name='book-search'),
    path('', include(router.urls)), 
]
