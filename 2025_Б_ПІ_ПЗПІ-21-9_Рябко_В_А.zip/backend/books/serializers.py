from rest_framework import serializers
from .models import Book

class BookSerializer(serializers.ModelSerializer):
    photo = serializers.SerializerMethodField()  # <- Правильне місце

    class Meta:
        model = Book
        fields = [
            'id',
            'title',
            'author',
            'genre',
            'status',
            'language',
            'description',
            'publication_year',
            'publisher',
            'page_count',
            'photo',
            'created_at',
            'updated_at',
        ]

    def get_photo(self, obj):
        request = self.context.get('request', None)
        if request and obj.photo and obj.photo.image:
            return request.build_absolute_uri(obj.photo.image.url)
        elif obj.photo and obj.photo.image:
            return obj.photo.image.url  # fallback: просто шлях
        return None

