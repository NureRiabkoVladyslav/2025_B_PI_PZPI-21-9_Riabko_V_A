from django.db import models
from photos.models import Photo

class Book(models.Model):
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('booked', 'Booked'),
    ]

    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    genre = models.CharField(max_length=100) 
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    language = models.CharField(max_length=50, blank=True)
    description = models.TextField(blank=True)
    publication_year = models.PositiveIntegerField(null=True, blank=True) 
    publisher = models.CharField(max_length=255, blank=True)
    page_count = models.PositiveIntegerField(null=True, blank=True)
    photo = models.ForeignKey(Photo, on_delete=models.SET_NULL, null=True, related_name='books')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title