from rest_framework import serializers
from .models import User
from roles.models import Role
from rest_framework.exceptions import PermissionDenied

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'email', 'role']

class ChangeUserRoleSerializer(serializers.ModelSerializer):
    role = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all())

    class Meta:
        model = User
        fields = ['role']

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    role = serializers.PrimaryKeyRelatedField(queryset=Role.objects.all())

    class Meta:
        model = User
        fields = ['email', 'password', 'role']

    def validate_role(self, value):
        request = self.context.get('request')
        if value.name == 'Administrator':
            if not request or not request.user.is_authenticated:
                raise PermissionDenied("Необхідно увійти в систему для створення адміністратора")
            if request.user.role.name != 'Administrator':
                raise PermissionDenied("Тільки адміністратор може призначати роль адміністратора")
        return value

    def create(self, validated_data):
        role = validated_data.pop('role', None)
        user = User.objects.create_user(
            email=validated_data['email'],
            password=validated_data['password'],
        )
        user.role = role
        user.save()
        return user