from rest_framework import generics, permissions
from rest_framework.exceptions import PermissionDenied
from .models import User, Role
from .serializers import (
    UserSerializer,
    ChangeUserRoleSerializer,
    RegisterSerializer,
)

class UserListView(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def dispatch(self, request, *args, **kwargs):
        if request.user.role.name not in ['Administrator', 'Librarian']:
            raise PermissionDenied("Тільки адміністратор та бібліотекар можуть переглядати список користувачів")
        return super().dispatch(request, *args, **kwargs)


class ChangeUserRoleView(generics.UpdateAPIView):
    queryset = User.objects.all()
    serializer_class = ChangeUserRoleSerializer
    permission_classes = [permissions.IsAuthenticated]

    def dispatch(self, request, *args, **kwargs):
        if request.user.role.name != 'Administrator':
            raise PermissionDenied("Тільки адміністратор може змінювати ролі")
        return super().dispatch(request, *args, **kwargs)


class DeleteUserView(generics.DestroyAPIView):
    queryset = User.objects.all()
    permission_classes = [permissions.IsAuthenticated]

    def perform_destroy(self, instance):
        if not self.request.user.is_authenticated:
            raise PermissionDenied("Необхідно увійти в систему")
        if not hasattr(self.request.user, 'role') or self.request.user.role is None:
            raise PermissionDenied("У користувача немає призначеної ролі")
        if self.request.user.role.name != 'Administrator':
            raise PermissionDenied("Лише адміністратор може видаляти користувачів")
        if self.request.user.id == instance.id:
            raise PermissionDenied("Адміністратор не може видалити свій власний обліковий запис")
        instance.delete()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer

    def perform_create(self, serializer):
        requested_role = self.request.data.get('role')
        requested_role_obj = Role.objects.get(id=requested_role)
        
        if requested_role_obj.name == 'Administrator':
            if not self.request.user.is_authenticated:
                raise PermissionDenied("Необхідно увійти в систему для створення адміністратора")
            if self.request.user.role.name != 'Administrator':
                raise PermissionDenied("Тільки адміністратор може створювати нових адміністраторів")
        
        serializer.save()
