from django.urls import path
from .views import SystemSettingsRetrieveUpdateView

urlpatterns = [
    path('settings/', SystemSettingsRetrieveUpdateView.as_view(), name='system-settings'),
]
