from rest_framework import generics, permissions
from .models import SystemSettings
from .serializers import SystemSettingsSerializer

class SystemSettingsRetrieveUpdateView(generics.RetrieveUpdateAPIView):
    queryset = SystemSettings.objects.all()
    serializer_class = SystemSettingsSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        obj, _ = SystemSettings.objects.get_or_create(pk=1)
        return obj
