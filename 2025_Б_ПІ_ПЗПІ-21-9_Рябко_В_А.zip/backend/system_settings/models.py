from django.db import models

class SystemSettings(models.Model):
    default_borrow_days = models.PositiveIntegerField(default=14)
    start_hour = models.PositiveIntegerField(default=9, help_text="Година початку роботи бібліотеки (0–23)")
    weekday_duration_hours = models.PositiveIntegerField(default=8, help_text="Тривалість роботи у будні (години)")
    weekend_duration_hours = models.PositiveIntegerField(default=4, help_text="Тривалість роботи у вихідні (години)")

    def __str__(self):
        return f"Позичання на {self.default_borrow_days} днів; Робота з {self.start_hour}:00"
