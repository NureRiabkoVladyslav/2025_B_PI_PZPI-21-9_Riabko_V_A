from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EventViewSet, EventListView
from .views import EventPhotoUploadView

router = DefaultRouter()
router.register(r'manage', EventViewSet, basename='event-manage')

urlpatterns = [
    path('list/', EventListView.as_view(), name='event-public-list'),  
    path('', include(router.urls)),                                   
    path('upload-photo/', EventPhotoUploadView.as_view(), name='event-photo-upload'),
]
