from django.db import models
from users.models import User
from photos.models import Photo

class Event(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    photo = models.ForeignKey(Photo, on_delete=models.SET_NULL, null=True, related_name='events')
    event_date = models.DateTimeField()
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_events')

    def __str__(self):
        return self.name
