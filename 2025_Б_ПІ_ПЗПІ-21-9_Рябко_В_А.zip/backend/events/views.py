# events/views.py

from rest_framework import viewsets, permissions, status
from rest_framework.response import Response
from .models import Event
from .serializers import EventSerializer
from rest_framework.permissions import AllowAny
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated

from .models import Event
from photos.models import Photo
# events/views.py

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [AllowAny]

    def retrieve(self, request, pk=None):
        try:
            event = Event.objects.get(pk=pk)
            serializer = EventSerializer(event, context={'request': request}) 
            return Response(serializer.data)
        except Event.DoesNotExist:
            return Response({'error': 'Подія не знайдена'}, status=status.HTTP_404_NOT_FOUND)

class EventPhotoUploadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        photo_file = request.FILES.get('image')
        event_id = request.data.get('event_id')

        if not photo_file or not event_id:
            return Response({'error': 'Не вказано фото або ID події'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            event = Event.objects.get(id=event_id)
        except Event.DoesNotExist:
            return Response({'error': 'Подія не знайдена'}, status=status.HTTP_404_NOT_FOUND)

        photo = Photo.objects.create(image=photo_file)
        event.photo = photo
        event.save()

        return Response({'message': 'Фото додано', 'photo_url': photo.image.url})
    
class EventListView(generics.ListAPIView):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [AllowAny]