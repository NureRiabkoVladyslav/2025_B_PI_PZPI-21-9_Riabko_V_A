from rest_framework import serializers
from .models import Event

class EventSerializer(serializers.ModelSerializer):
    photo = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = ['id', 'name', 'description', 'event_date', 'photo']

    def get_photo(self, obj):
        request = self.context.get('request')
        if obj.photo and obj.photo.image:
            if request:
                return request.build_absolute_uri(obj.photo.image.url)
            return obj.photo.image.url
        return None
    
