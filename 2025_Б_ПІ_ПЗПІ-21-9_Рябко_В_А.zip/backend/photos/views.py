from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response
from rest_framework import status, permissions
from .models import Photo
from books.models import Book

class PhotoUploadView(APIView):
    parser_classes = [MultiPartParser]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        uploaded_file = request.FILES.get('photo')
        book_id = request.data.get('book_id')

        if not uploaded_file:
            return Response({"error": "Файл не надіслано"}, status=status.HTTP_400_BAD_REQUEST)

        photo = Photo.objects.create(image=uploaded_file)

        if book_id:
            try:
                book = Book.objects.get(pk=book_id)
                book.photo = photo
                book.save()
            except Book.DoesNotExist:
                return Response({"error": "Книга не знайдена"}, status=status.HTTP_404_NOT_FOUND)

        return Response({"message": "Фото завантажено", "photo_id": photo.id}, status=status.HTTP_201_CREATED)
